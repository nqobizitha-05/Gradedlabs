import HomeScreen from "./HomeScreen"
import { StyleSheet, Text, View, Image, SafeAreaView } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import DetailScreen from "./DetailScreen"

export default function App() {
  const Stack = createNativeStackNavigator();
  return (
    <View style={styles.container}>
      
      
      <SafeAreaView>
        
        <HomeScreen />
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
