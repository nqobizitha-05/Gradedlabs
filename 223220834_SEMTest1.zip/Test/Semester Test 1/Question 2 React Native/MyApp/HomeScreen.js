import { useState, useEffect} from "react";
import { View, FlatList, Text, Image, StyleSheet } from "react-native";

export default function HomeScreen(){
        const [products, setProducts] = useState([]);
        const [loading, setLoading] = useState(true);
    
    
        useEffect(() => {
            const fetchProducts = async () => {
            try {
              const response = await fetch("https://fakestoreapi.com/products");
              const data = await response.json();
              setProducts(data);
              setLoading(false);
            } catch (error) {
              console.error("Error fetching products:", error);
              setLoading(false);
            }
        };
    
        fetchProducts();
        }, [])

        return(
            <>
                <FlatList 
                data={products} 
                keyExtractor={(item, index) => index.toString()}
                renderItem={({item}) => (
                    <View style={styles.card}>
                        <Image
                         source={{uri: item.image}} 
                         style={styles.image}/>
                        <Text>{item.title}</Text>
                    </View>
                )}
                />
            </>
        )
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 15,
    marginVertical: 10,
    marginHorizontal: 5,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 5, 
  },

  image: {
    width: 120,
    height: 120,
    borderRadius: 10,
    marginBottom: 10,
}
});